import { AvailablePipe } from './available.pipe';

describe('AvailablePipe', () => {
  it('create an instance', () => {
    const pipe = new AvailablePipe();
    expect(pipe).toBeTruthy();
  });
});
